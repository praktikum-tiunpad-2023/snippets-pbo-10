/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kalkulatorgui;

/**
 *
 * @author Alif
 */
/* Nama program : KalkulatorClass.java
Nama : Alif Al Husaini
NPM : 140810220036
Tanggal buat  23 November 2023
Deskripsi : Class KalkulatorClass
----------------------------------------------------------------- */
public class KalkulatorClass {

    int operator = 0;
    double operand1 = 0.0;
    double operand2 = 0.0;

    public void setOperand(String opr) {
        if (!opr.equals("")) {
            if (operator == 0) {
                operand1 = Double.parseDouble(opr);
            } else {
                operand2 = Double.parseDouble(opr);
            }
        }
    }

    public void setOperator(int operator) {
        this.operator = operator;
    }

    public void setOperand1(double operand1) {
        this.operand1 = operand1;
    }

    public void setOperand2(double operand2) {
        this.operand2 = operand2;
    }


    public double getOperand1() {
        return operand1;
    }

    public double getOperand2() {
        return operand2;
    }

    public double process() {
        double hasil = 0;
        switch (operator) {
            case 1:
                hasil = operand1 + operand2;
                break;
            case 2:
                hasil = operand1 - operand2;
                break;
            case 3:
                hasil = operand1 * operand2;
                break;
            case 4:
                hasil = operand1 / operand2;
                break;
            default:
                hasil = operand1;
        }
        operand1 = hasil;
        return hasil;
    }
    
}
