/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package PackageClass;
import PackageConnect.Koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
/**
 *
 * @author Alif
 */
public class DetailTransaksi {
    private int ID_Detail_Transaksi;
    private int ID_Transaksi;
    private int ID_Sepatu;
    private int Jumlah;
    private double Subtotal;

    // Constructor
    public DetailTransaksi() {
        // Kosongkan saja, atau tambahkan parameter sesuai kebutuhan
    }

    // Setter dan getter
    public int getID_Detail_Transaksi() {
        return ID_Detail_Transaksi;
    }

    public void setID_Detail_Transaksi(int ID_Detail_Transaksi) {
        this.ID_Detail_Transaksi = ID_Detail_Transaksi;
    }

    public int getID_Transaksi() {
        return ID_Transaksi;
    }

    public void setID_Transaksi(int ID_Transaksi) {
        this.ID_Transaksi = ID_Transaksi;
    }

    public int getID_Sepatu() {
        return ID_Sepatu;
    }

    public void setID_Sepatu(int ID_Sepatu) {
        this.ID_Sepatu = ID_Sepatu;
    }

    public int getJumlah() {
        return Jumlah;
    }

    public void setJumlah(int Jumlah) {
        this.Jumlah = Jumlah;
    }

    public double getSubtotal() {
        return Subtotal;
    }

    public void setSubtotal(double Subtotal) {
        this.Subtotal = Subtotal;
    }

   // Metode untuk insert detail transaksi
    public void insertDetailTransaksi(Koneksi koneksi) {
        try {
            Connection connection = koneksi.getCon();
            String query = "INSERT INTO detail_transaksi (ID_Transaksi, ID_Sepatu, Jumlah, Subtotal) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, ID_Transaksi);
            preparedStatement.setInt(2, ID_Sepatu);
            preparedStatement.setInt(3, Jumlah);
            preparedStatement.setDouble(4, Subtotal);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Metode untuk update detail transaksi
    public void updateDetailTransaksi(Koneksi koneksi) {
        try {
            Connection connection = koneksi.getCon();
            String query = "UPDATE detail_transaksi SET ID_Transaksi = ?, ID_Sepatu = ?, Jumlah = ?, Subtotal = ? WHERE ID_Detail_Transaksi = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, ID_Transaksi);
            preparedStatement.setInt(2, ID_Sepatu);
            preparedStatement.setInt(3, Jumlah);
            preparedStatement.setDouble(4, Subtotal);
            preparedStatement.setInt(5, ID_Detail_Transaksi);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Metode untuk delete detail transaksi
    public void deleteDetailTransaksi(Koneksi koneksi) {
        try {
            Connection connection = koneksi.getCon();
            String query = "DELETE FROM detail_transaksi WHERE ID_Detail_Transaksi = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, ID_Detail_Transaksi);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void hitungSubtotal(Koneksi koneksi) {
        try {
            Connection connection = koneksi.getCon();
            String query = "SELECT Harga FROM sepatu WHERE ID_Sepatu = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, ID_Sepatu);

            // Eksekusi query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Mengambil harga dari hasil query
            if (resultSet.next()) {
                double hargaSepatu = resultSet.getDouble("Harga");
                Subtotal = Jumlah * hargaSepatu;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Metode untuk menghitung total transaksi
    public static double hitungTotalTransaksi(Koneksi koneksi, int idTransaksi) {
        double total = 0;

        try {
            Connection connection = koneksi.getCon();
            String query = "SELECT SUM(Subtotal) AS Total FROM detail_transaksi WHERE ID_Transaksi = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idTransaksi);

            // Eksekusi query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Mengambil hasil query
            if (resultSet.next()) {
                total = resultSet.getDouble("Total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return total;
    }
}