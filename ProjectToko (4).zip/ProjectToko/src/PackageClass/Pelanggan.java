/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package PackageClass;

/**
 *
 * @author Alif
 */

import PackageConnect.Koneksi;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Pelanggan {
    private int ID_Pelanggan;
    private String kontak;
    private String nama;

    // Constructor
    public Pelanggan(int ID_Pelanggan, String kontak, String nama) {
        this.ID_Pelanggan = ID_Pelanggan;
        this.kontak = kontak;
        this.nama = nama;
    }

    public Pelanggan() {
        this.ID_Pelanggan = 0;
        this.kontak = "";
        this.nama = "";
    }

    // Getter methods
    public int getID_Pelanggan() {
        return ID_Pelanggan;
    }

    public String getKontak() {
        return kontak;
    }

    public String getNama() {
        return nama;
    }

    // Setter methods
    public void setID_Pelanggan(int ID_Pelanggan) {
        this.ID_Pelanggan = ID_Pelanggan;
    }

    public void setKontak(String kontak) {
        this.kontak = kontak;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    // Fungsi insert pelanggan
    public void insert(Koneksi koneksi) {
        try {
            String query = "INSERT INTO pelanggan (Kontak, Nama) VALUES (?, ?)";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, kontak);
            preparedStatement.setString(2, nama);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Fungsi update pelanggan
    public void update(Koneksi koneksi) {
        try {
            String query = "UPDATE pelanggan SET Kontak = ?, Nama = ? WHERE ID_Pelanggan = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, kontak);
            preparedStatement.setString(2, nama);
            preparedStatement.setInt(3, ID_Pelanggan);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Fungsi delete
    public void delete(Koneksi koneksi) {
        try {
            String query = "DELETE FROM pelanggan WHERE ID_Pelanggan = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setInt(1, ID_Pelanggan);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Fungsi cek transaksi
    public boolean hasTransactions(Koneksi koneksi) {
        try {
            String query = "SELECT COUNT(*) AS total FROM transaksi WHERE ID_Pelanggan = ?";
            try (PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query)) {
                preparedStatement.setInt(1, this.getID_Pelanggan());
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    int total = resultSet.getInt("total");
                    return total > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public int getIdPelangganDariDatabase(Koneksi koneksi, String namaPelanggan) throws SQLException {
        String query = "SELECT ID_Pelanggan FROM pelanggan WHERE Nama = ?";
        PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
        preparedStatement.setString(1, namaPelanggan);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            return resultSet.getInt("ID_Pelanggan");
        } else {
            throw new SQLException("Pelanggan tidak ditemukan.");
        }
    }

}
