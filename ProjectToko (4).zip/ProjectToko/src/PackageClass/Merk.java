/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package PackageClass;

/**
 *
 * @author Alif
 */
import java.sql.PreparedStatement;
import java.sql.SQLException;
import PackageConnect.Koneksi;
import java.sql.*;

public class Merk {

    private int ID_Merk;
    private String Nama_Merk;

    // Constructor
    public Merk(int ID_Merk, String Nama_Merk) {
        this.ID_Merk = ID_Merk;
        this.Nama_Merk = Nama_Merk;
    }

    public Merk() {
        // Constructor kosong
    }

    // Getter methods
    public int getID_Merk() {
        return ID_Merk;
    }

    public String getNama_Merk() {
        return Nama_Merk;
    }

    // Setter methods
    public void setID_Merk(int ID_Merk) {
        this.ID_Merk = ID_Merk;
    }

    public void setNama_Merk(String Nama_Merk) {
        this.Nama_Merk = Nama_Merk;
    }

    // Metode untuk insert merk
    public void insertMerk(Koneksi koneksi) {
        try {
            String query = "INSERT INTO merk (Nama_Merk) VALUES (?)";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, Nama_Merk);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Metode untuk update merk
    public void updateMerk(Koneksi koneksi) {
        try {
            String query = "UPDATE merk SET Nama_Merk = ? WHERE ID_Merk = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, Nama_Merk);
            preparedStatement.setInt(2, ID_Merk);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Metode untuk delete merk
    public void deleteMerk(Koneksi koneksi) {
        try {
            String query = "DELETE FROM merk WHERE ID_Merk = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setInt(1, ID_Merk);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public int getMerkIdByName(Koneksi koneksi, String namaMerk) {
        int idMerk = 0;

        try {
            // Query untuk mendapatkan ID_Merk berdasarkan nama merk
            String query = "SELECT ID_Merk FROM merk WHERE Nama_Merk = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, namaMerk);

            // Eksekusi query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Jika ada hasil, ambil ID_Merk
            if (resultSet.next()) {
                idMerk = resultSet.getInt("ID_Merk");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return idMerk;
    }
    
    public boolean isMerkConnectedToSepatu(Koneksi koneksi) {
        try {
            String query = "SELECT COUNT(*) FROM sepatu WHERE ID_Merk = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setInt(1, ID_Merk);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}

