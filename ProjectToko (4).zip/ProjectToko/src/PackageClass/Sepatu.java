/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package PackageClass;

/**
 *
 * @author Alif
 */
import java.sql.PreparedStatement;
import java.sql.*;
import PackageConnect.Koneksi;

public class Sepatu {

    private int ID_Sepatu;
    private String Nama_Sepatu;
    private long Harga;
    private int Stok;
    private String Deskripsi;
    private int ID_Merk;

    // Constructor
    public Sepatu(int ID_Sepatu, String Nama_Sepatu, int Harga, int Stok, String Deskripsi, int ID_Merk) {
        this.ID_Sepatu = ID_Sepatu;
        this.Nama_Sepatu = Nama_Sepatu;
        this.Harga = Harga;
        this.Stok = Stok;
        this.Deskripsi = Deskripsi;
        this.ID_Merk = ID_Merk;
    }

    public Sepatu() {
        // Constructor kosong
    }

    // Getter methods
    public int getID_Sepatu() {
        return ID_Sepatu;
    }

    public String getNama_Sepatu() {
        return Nama_Sepatu;
    }

    public long getHarga() {
        return Harga;
    }

    public int getStok() {
        return Stok;
    }

    public String getDeskripsi() {
        return Deskripsi;
    }

    public int getID_Merk() {
        return ID_Merk;
    }

    // Setter methods
    public void setID_Sepatu(int ID_Sepatu) {
        this.ID_Sepatu = ID_Sepatu;
    }

    public void setNama_Sepatu(String Nama_Sepatu) {
        this.Nama_Sepatu = Nama_Sepatu;
    }

    public void setHarga(long Harga) {
        this.Harga = Harga;
    }

    public void setStok(int Stok) {
        this.Stok = Stok;
    }

    public void setDeskripsi(String Deskripsi) {
        this.Deskripsi = Deskripsi;
    }

    public void setID_Merk(int ID_Merk) {
        this.ID_Merk = ID_Merk;
    }

    // Metode untuk insert sepatu
    public void insertSepatu(Koneksi koneksi) {
        try {
            String query = "INSERT INTO sepatu (Nama_Sepatu, Harga, Stok, Deskripsi, ID_Merk) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, Nama_Sepatu);
            preparedStatement.setLong(2, Harga);
            preparedStatement.setInt(3, Stok);
            preparedStatement.setString(4, Deskripsi);
            preparedStatement.setInt(5, ID_Merk);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Metode untuk update sepatu
    public void updateSepatu(Koneksi koneksi) {
        try {
            String query = "UPDATE sepatu SET Nama_Sepatu = ?, Harga = ?, Stok = ?, Deskripsi = ?, ID_Merk = ? WHERE ID_Sepatu = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, Nama_Sepatu);
            preparedStatement.setLong(2, Harga);
            preparedStatement.setInt(3, Stok);
            preparedStatement.setString(4, Deskripsi);
            preparedStatement.setInt(5, ID_Merk);
            preparedStatement.setInt(6, ID_Sepatu);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Metode untuk delete sepatu
    public void deleteSepatu(Koneksi koneksi) {
        try {
            String query = "DELETE FROM sepatu WHERE ID_Sepatu = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setInt(1, ID_Sepatu);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean hasTransactions(Koneksi koneksi) {
        try {
            String query = "SELECT COUNT(*) FROM transaksi WHERE ID_Sepatu = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setInt(1, ID_Sepatu);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0; // Mengembalikan true jika ada transaksi terkait
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false; // Mengembalikan false jika terjadi kesalahan
    }
    
    public int getHargaSepatuDariDatabase(Koneksi koneksi, String namaSepatu) {
        int hargaSepatu = 0;

        try {
            // Query untuk mendapatkan harga sepatu berdasarkan nama sepatu
            String query = "SELECT Harga FROM sepatu WHERE Nama_Sepatu = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, namaSepatu);
            ResultSet rs = preparedStatement.executeQuery();

            // Jika data ditemukan, ambil nilai harga
            if (rs.next()) {
                hargaSepatu = rs.getInt("Harga");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle kesalahan jika terjadi
        }

        return hargaSepatu;
    }
    
        public int getStokSepatuFromDatabase(Koneksi koneksi, String namaSepatu) {
        int stok = 0;

        try {
            String query = "SELECT Stok FROM sepatu WHERE Nama_Sepatu = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, namaSepatu);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                stok = resultSet.getInt("Stok");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception according to your application's needs
        }

        return stok;
    }
        
    public int getIdSepatuDariDatabase(Koneksi koneksi, String namaSepatu) {
        int idSepatu = -1; // Default jika tidak ditemukan

        try {
            String query = "SELECT ID_Sepatu FROM sepatu WHERE Nama_Sepatu = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setString(1, namaSepatu);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                idSepatu = resultSet.getInt("ID_Sepatu");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return idSepatu;
    }

  public void updateStokSepatu(Koneksi koneksi, int idSepatu, int newStok) throws SQLException {
        try {
            String query = "UPDATE sepatu SET Stok = ? WHERE ID_Sepatu = ?";
            PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
            preparedStatement.setInt(1, newStok);
            preparedStatement.setInt(2, idSepatu);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw e; // Rethrow the exception for handling in the calling method
        }
    }

}

