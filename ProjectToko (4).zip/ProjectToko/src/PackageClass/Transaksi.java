/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package PackageClass;

/**
 *
 * @author Alif
 */
import java.sql.PreparedStatement;
import java.sql.*;
import PackageConnect.Koneksi;
import java.util.Date;
public class Transaksi {
    private int ID_Transaksi;
    private int ID_Pegawai;
    private int ID_Pelanggan;
    private Date Tanggal_Transaksi;
    private double Total_Harga;

    // Constructor
    public Transaksi() {
        // Kosongkan saja, atau tambahkan parameter sesuai kebutuhan
    }

    // Setter dan getter
    public int getID_Transaksi() {
        return ID_Transaksi;
    }

    public void setID_Transaksi(int ID_Transaksi) {
        this.ID_Transaksi = ID_Transaksi;
    }

    public int getID_Pegawai() {
        return ID_Pegawai;
    }

    public void setID_Pegawai(int ID_Pegawai) {
        this.ID_Pegawai = ID_Pegawai;
    }

    public int getID_Pelanggan() {
        return ID_Pelanggan;
    }

    public void setID_Pelanggan(int ID_Pelanggan) {
        this.ID_Pelanggan = ID_Pelanggan;
    }

    public Date getTanggal_Transaksi() {
        return Tanggal_Transaksi;
    }

    public void setTanggal_Transaksi(Date Tanggal_Transaksi) {
        this.Tanggal_Transaksi = Tanggal_Transaksi;
    }

    public double getTotal_Harga() {
        return Total_Harga;
    }

    public void setTotal_Harga(double Total_Harga) {
        this.Total_Harga = Total_Harga;
    }


    public void insertTransaksi(Koneksi koneksi) throws SQLException {
        String query = "INSERT INTO transaksi (ID_Pegawai, ID_Pelanggan, Tanggal_Transaksi, Total_Harga) VALUES (?, ?, ?, ?)";
        PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
        preparedStatement.setInt(1, ID_Pegawai);
        preparedStatement.setInt(2, ID_Pelanggan);

        // Convert java.util.Date to java.sql.Date
        java.sql.Date sqlDate = new java.sql.Date(Tanggal_Transaksi.getTime());
        preparedStatement.setDate(3, sqlDate);

        preparedStatement.setDouble(4, Total_Harga);

        int affectedRows = preparedStatement.executeUpdate();

        if (affectedRows == 0) {
            throw new SQLException("Insert transaksi gagal, tidak ada baris yang terpengaruh.");
        }

        // Mendapatkan ID_Transaksi yang baru saja dibuat
        try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
            if (generatedKeys.next()) {
                ID_Transaksi = generatedKeys.getInt(1);
            } else {
                throw new SQLException("Insert transaksi gagal, tidak dapat mendapatkan ID_Transaksi.");
            }
        }
    }



    

    public int getIdTransaksiTerakhir(Koneksi koneksi) throws SQLException {
        String query = "SELECT MAX(ID_Transaksi) AS ID_Terakhir FROM transaksi";
        Statement statement = koneksi.getCon().createStatement();
        ResultSet resultSet = statement.executeQuery(query);

        if (resultSet.next()) {
            return resultSet.getInt("ID_Terakhir");
        } else {
            throw new SQLException("ID_Transaksi terakhir tidak ditemukan.");
        }
    }
}