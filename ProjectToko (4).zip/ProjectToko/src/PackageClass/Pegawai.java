package PackageClass;

import PackageConnect.Koneksi;
import javax.swing.JOptionPane;
import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;

/**
 * Kelas untuk representasi objek Pegawai
 *
 * @author Alif
 */
public class Pegawai {

    private int ID_Pegawai;
    private String nama;
    private String username;  
    private String email;
    private String kataSandi;
    private String peran;

    // Constructor
    public Pegawai(int ID_Pegawai, String nama, String username, String email, String kataSandi, String peran) {
        this.ID_Pegawai = ID_Pegawai;
        this.nama = nama;
        this.username = username;
        this.email = email;
        this.kataSandi = kataSandi;
        this.peran = peran;
    }

    public Pegawai() {
        this.ID_Pegawai = 0;
        this.nama = "";
        this.username = "";
        this.email = "";
        this.kataSandi = "";
        this.peran = "";
    }

    // Getter methods
    public int getID_Pegawai() {
        return this.ID_Pegawai;
    }

    public String getNama() {
        return nama;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getKataSandi() {
        return kataSandi;
    }

    public String getPeran() {
        return this.peran;
    }

    // Setter methods
    public void setID_Pegawai(int ID_Pegawai) {
        this.ID_Pegawai = ID_Pegawai;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setKataSandi(String kataSandi) {
        this.kataSandi = kataSandi;
    }

    public void setPeran(String peran) {
        this.peran = peran;
    }

    // Metode untuk mengupdate informasi pegawai
    public void tambahPegawai(Koneksi koneksi) {
        // Menggunakan BCrypt untuk mengenkripsi password sebelum disimpan
        String hashedPassword = BCrypt.hashpw(kataSandi, BCrypt.gensalt());
        koneksi.query("INSERT INTO pegawai (Nama, Username, Email, Kata_Sandi, Peran) VALUES ('"
                + nama + "', '" + username + "', '" + email + "', '" + hashedPassword + "', '" + peran + "')");
    }

//    public boolean login(Koneksi koneksi, String inputUsername, String inputPassword) {
//        boolean berhasilLogin = false;
//        String query = "SELECT * FROM pegawai WHERE Username = '" + inputUsername + "'";
//        ResultSet rs = koneksi.getData(query);
//
//        try {
//            if (rs.next()) {
//                // Jika data ditemukan, verifikasi password dengan BCrypt
//                String hashedPassword = rs.getString("Kata_Sandi");
//                if (BCrypt.checkpw(inputPassword, hashedPassword)) {
//                    berhasilLogin = true;
//                }
//            }
//        } catch (SQLException e) {
//            // Tangani kesalahan eksekusi query di sini
//            e.printStackTrace();
//        }
//
//        return berhasilLogin;
//    }
    public void updatePegawai(Koneksi koneksi, String pass) {
        // Menggunakan BCrypt untuk mengenkripsi password baru sebelum disimpan
        String hashedPassword = BCrypt.hashpw(pass, BCrypt.gensalt());
        koneksi.query("UPDATE pegawai SET Nama = '" + nama + "', Email = '" + email
                + "', Kata_Sandi = '" + hashedPassword + "', Peran = '" + peran + "' WHERE ID_Pegawai = " + ID_Pegawai);
    }

    public boolean isUsernameExistsForUpdate(Koneksi koneksi, int idPegawai, String newUsername) {
        try {
            String query = "SELECT COUNT(*) AS total FROM pegawai WHERE Username = ? AND ID_Pegawai != ?";
            try (PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query)) {
                preparedStatement.setString(1, newUsername);
                preparedStatement.setInt(2, idPegawai);
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    int total = resultSet.getInt("total");
                    return total > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isUsernameExists(Koneksi koneksi, String username) {
        try {
            String query = "SELECT COUNT(*) AS total FROM pegawai WHERE Username = ?";
            try (PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query)) {
                preparedStatement.setString(1, username);
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    int total = resultSet.getInt("total");
                    return total > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

 public void updateWithOldPassword(Koneksi koneksi) {
    // Jika password baru tidak diberikan, abaikan kolom Kata_Sandi dalam pernyataan UPDATE
    koneksi.query("UPDATE pegawai SET Nama = '" + nama + "', Email = '" + email
            + "', Peran = '" + peran + "' WHERE ID_Pegawai = " + ID_Pegawai);
}


    public void delete(Koneksi koneksi) {
        // Hapus pegawai berdasarkan ID_Pegawai
        koneksi.query("DELETE FROM pegawai WHERE ID_Pegawai = " + ID_Pegawai);
    }

    public String getPegawaiPeranDariDatabase(Koneksi koneksi, int idPegawai) {
        peran = "";

        try {
            String query = "SELECT Peran FROM pegawai WHERE ID_Pegawai = " + idPegawai;
            ResultSet rs = koneksi.getData(query);

            if (rs.next()) {
                peran = rs.getString("Peran");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return peran;
    }
    
       public String pegawaiFromDb(Koneksi koneksi, int idPegawai) {
        nama = "";

        try {
            String query = "SELECT Nama FROM pegawai WHERE ID_Pegawai = " + idPegawai;
            ResultSet rs = koneksi.getData(query);

            if (rs.next()) {
                nama = rs.getString("Nama");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return nama;
    }

    public LoginInfo loginAndGetInfo(Koneksi koneksi, String inputUsername, String inputPassword) {
        boolean berhasilLogin = false;
        int idPegawai = 0;
        String peran = null;

        String query = "SELECT * FROM pegawai WHERE Username = '" + inputUsername + "'";
        ResultSet rs = koneksi.getData(query);

        try {
            if (rs.next()) {
                idPegawai = rs.getInt("ID_Pegawai");
                peran = rs.getString("Peran");

                // Jika data ditemukan, verifikasi password dengan BCrypt
                String hashedPassword = rs.getString("Kata_Sandi");
                if (BCrypt.checkpw(inputPassword, hashedPassword)) {
                    berhasilLogin = true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return new LoginInfo(berhasilLogin, idPegawai, peran);
    }

   public boolean hasTransactions(Koneksi koneksi) {
    try {
        String query = "SELECT COUNT(*) AS total FROM transaksi WHERE ID_Pegawai = ?";
        try (PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query)) {
            preparedStatement.setInt(1, this.getID_Pegawai());
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int total = resultSet.getInt("total");
                return total > 0;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}

   public int getIdPegawaiDariDatabase(Koneksi koneksi, String namaPegawai) throws SQLException {
        String query = "SELECT ID_Pegawai FROM pegawai WHERE Nama = ?";
        PreparedStatement preparedStatement = koneksi.getCon().prepareStatement(query);
        preparedStatement.setString(1, namaPegawai);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            return resultSet.getInt("ID_Pegawai");
        } else {
            throw new SQLException("Pegawai tidak ditemukan.");
        }
    }

}
