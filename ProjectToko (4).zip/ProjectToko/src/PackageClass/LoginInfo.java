/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package PackageClass;

/**
 *
 * @author Alif
 */
public class LoginInfo {
    private final boolean loginSuccess;
    private final int idPegawai;
    private final String peran;

    public LoginInfo(boolean loginSuccess, int idPegawai, String peran) {
        this.loginSuccess = loginSuccess;
        this.idPegawai = idPegawai;
        this.peran = peran;
    }

    public boolean isLoginSuccess() {
        return loginSuccess;
    }

    public int getIdPegawai() {
        return idPegawai;
    }

    public String getPeran() {
        return peran;
    }
}
