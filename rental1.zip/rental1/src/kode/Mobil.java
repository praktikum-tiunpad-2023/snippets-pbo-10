/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package kode;

/**
 *
 * @author Alif
 */
import java.sql.ResultSet;
public class Mobil {
    private String id;
    private String jenis;
    private String sewa;
    private String stok;

    public Mobil() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public String getSewa() {
        return sewa;
    }

    public void setSewa(String sewa) {
        this.sewa = sewa;
    }

    public String getStok() {
        return stok;
    }

    public void setStok(String stok) {
        this.stok = stok;
    }

    public void insertMobil() {
        Koneksi kon = new Koneksi();
        String s = "INSERT INTO mobil VALUES ('" + this.id + "', '" + this.jenis + "', '" + this.sewa + "', '" + this.stok + "')";
        kon.query(s);
    }

    public void updateMobil() {
        Koneksi kon = new Koneksi();
        String s = "UPDATE mobil SET jenis = '" + this.jenis + "', sewa = '" + this.sewa + "', stok = '" + this.stok + "' WHERE id_mobil = '" + this.id + "'";
        kon.query(s);
    }

    public void deleteMobil() {
        Koneksi kon = new Koneksi();
        String s = "DELETE FROM mobil WHERE id_mobil = '" + this.id + "'";
        kon.query(s);
    }

    public ResultSet getMobil() {
        ResultSet r = null;
        Koneksi kon = new Koneksi();
        String s = "SELECT * FROM mobil WHERE id_mobil = '" + this.id + "'";
        r = kon.getData(s);
        return r;
    }
}

