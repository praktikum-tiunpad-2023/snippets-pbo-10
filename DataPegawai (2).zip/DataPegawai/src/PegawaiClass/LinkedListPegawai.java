/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PegawaiClass;

/**
 *
 * @author Alif
 */
public class LinkedListPegawai {

    private Node head;

    public LinkedListPegawai() {
        head = null;
    }

    public Node getHead() {
        return head;
    }

    public void setHead(Node newHead) {
        head = newHead;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void insertFirst(Pegawai pegawai) {
        Node newNode = new Node(pegawai);
        newNode.next = head;
        head = newNode;
    }

    public void insertLast(Pegawai pegawai) {
        Node newNode = new Node(pegawai);
        if (isEmpty()) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public Node deleteFirst() {
        if (isEmpty()) {
            return null;
        }
        Node temp = head;
        head = head.next;
        return temp;
    }

    public Node deleteLast() {
        if (isEmpty()) {
            return null;
        }
        if (head.next == null) {
            Node temp = head;
            head = null;
            return temp;
        }
        Node current = head;
        Node prev = null;
        while (current.next != null) {
            prev = current;
            current = current.next;
        }
        prev.next = null;
        return current;
    }

    public Node deleteWithKey(String nip) {
        if (isEmpty()) {
            return null;
        }
        Node current = head;
        Node prev = null;
        while (current != null && !current.getPegawai().getNip().equals(nip)) {
            prev = current;
            current = current.next;
        }
        if (current == null) {
            return null;
        }
        if (current == head) {
            head = head.next;
        } else {
            prev.next = current.next;
        }
        return current;
    }

    public void traversal() {
        Node current = head;
        while (current != null) {
            Pegawai pegawai = current.getPegawai();
            System.out.println("Nama: " + pegawai.getNama() + ", NIP: " + pegawai.getNip() + ", Golongan: " + pegawai.getGolongan());
            current = current.next;
        }
    }

    public Node search(String key, String type) {
        Node current = head;
        while (current != null) {
            Pegawai pegawai = current.getPegawai();
            if (type.equals("NIP") && pegawai.getNip().equals(key)) {
                return current;
            } else if (type.equals("Nama") && pegawai.getNama().equalsIgnoreCase(key)) {
                return current;
            } else if (type.equals("Gol") && Integer.toString(pegawai.getGolongan()).equals(key)) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    public double hitungRataRataGaji() {
        if (isEmpty()) {
            return 0.0;
        }

        Node current = head;
        int count = 0;
        long totalGaji = 0;

        while (current != null) {
            totalGaji += current.getPegawai().hitungGaji();
            count++;
            current = current.next;
        }

        return (double) totalGaji / count;
    }

    public long hitungGajiTerendah() {
        if (isEmpty()) {
            return 0;
        }

        Node current = head;
        long minGaji = Long.MAX_VALUE;

        while (current != null) {
            long gaji = current.getPegawai().hitungGaji();
            if (gaji < minGaji) {
                minGaji = gaji;
            }
            current = current.next;
        }

        return minGaji;
    }

    public double hitungRataRataGolongan() {
        if (isEmpty()) {
            return 0.0;
        }

        Node current = head;
        int count = 0;
        int totalGol = 0;

        while (current != null) {
            totalGol += current.getPegawai().getGolongan();
            count++;
            current = current.next;
        }

        return (double) totalGol / count;
    }

    public long hitungGajiTertinggi() {
        if (isEmpty()) {
            return 0;
        }

        Node current = head;
        long maxGaji = Long.MIN_VALUE;

        while (current != null) {
            long gaji = current.getPegawai().hitungGaji();
            if (gaji > maxGaji) {
                maxGaji = gaji;
            }
            current = current.next;
        }

        return maxGaji;
    }

}
