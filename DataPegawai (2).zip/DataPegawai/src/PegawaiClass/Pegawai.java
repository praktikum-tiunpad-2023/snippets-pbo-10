/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PegawaiClass;

/**
 *
 * @author Alif
 */

public class Pegawai {
    private String nama;
    private String nip;
    private int golongan;

    public Pegawai() {
        this.nama = "";
        this.nip = "";
        this.golongan = 0;
    }

    public String getNama() {
        return this.nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNip() {
        return this.nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public int getGolongan() {
        return this.golongan;
    }

    public void setGolongan(int golongan) {
        this.golongan = golongan;
    }


    public long hitungGaji() {
        switch (this.golongan) {
            case 1:
                return 4000000;
            case 2:
                return 6000000;
            default:
                return 8000000;
        }
    }
}





