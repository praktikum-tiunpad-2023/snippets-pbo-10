/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pegawai;
import Koneksi.Koneksi;
/**
 *
 * @author TEMURI
 */
public class Pegawai {
    private String nama;
    private String nip;
    private int golongan;

    public Pegawai() {
        this.nama = "";
        this.nip = "";
        this.golongan = 0;
    }

    public String getNama() {
        return this.nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNip() {
        return this.nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public int getGolongan() {
        return this.golongan;
    }

    public void setGolongan(int golongan) {
        this.golongan = golongan;
    }


    public long GajiGol() {
        switch (this.golongan) {
            case 1:
                return 4000000;
            case 2:
                return 6000000;
            default:
                return 8000000;
        }
    }
    
    
    public String insertPegawai(){
        Koneksi kon = new Koneksi();
        long gaji = GajiGol();
        
        String s = "INSERT INTO pegawai VALUES ('"+this.nip+
                            "','"+this.nama+
                            "','"+this.golongan+
                            "','"+gaji+
                            "','"+"')";
        kon.query(s);
        return(s);
    }

    public String updatePegawai(){    
        Koneksi kon = new Koneksi();
        long gaji = GajiGol();
        
        String s =  "UPDATE pegawai SET nama='" +
                    this.nama + "', golongan=" + 
                    this.golongan + ", gaji=" + 
                    gaji + " WHERE nip='" + 
                    this.nip + "'";
        kon.query(s);
        return(s);
    }

    public String deletePegawai() {
        Koneksi kon = new Koneksi();
        String s = "DELETE FROM pegawai WHERE nip='" + this.nip + "'";
        kon.query(s);
        return s;
    }

}
