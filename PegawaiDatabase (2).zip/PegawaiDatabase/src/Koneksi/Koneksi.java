/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package Koneksi;

/**b 
 *
 * @author Alif
 */
/* Nama program : KalkulatorClass.java
Nama : Alif Al Husaini
NPM : 140810220036
Tanggal buat  29 November 2023
Deskripsi : Class Koneksi
----------------------------------------------------------------- */
import java.sql.*;
import javax.swing.JOptionPane;

public class Koneksi {

    private String user;
    private String pwd; 
    private String  host = "localhost:3306";
    private String db = "dbpegawai";; 
    private String url;
    private Statement st = null;
    private Connection con = null;
    private ResultSet rs = null;

    public Koneksi() {
        user = "root";
        pwd = "";
       
        url = "";
        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (ClassNotFoundException e) {

            JOptionPane.showMessageDialog(null, "Ada kesalahan Driver JDBC "
                    + "tidak barhasil Load");

        }
        try {

            url = "jdbc:mysql://" + host + "/" + db;
            con = (Connection) DriverManager.getConnection(url, user, pwd);


        } catch (SQLException se) {

            JOptionPane.showMessageDialog(null, "Perintah salah.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(null, "Driver tidak Terhubung");

        }
    }

    public ResultSet getData(String SQLString) {
        try {
            st = (Statement) con.createStatement();
            rs = st.executeQuery(SQLString);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error:" + e.getMessage(),
                    "Communication Error", JOptionPane.WARNING_MESSAGE);

        }
        return rs;
    }

    public void query(String SQLString) {
        int hsl;
        try {
            st = (Statement) con.createStatement();
            hsl = st.executeUpdate(SQLString);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error:" + e.getMessage(),
                    "Communication Error", JOptionPane.WARNING_MESSAGE);

        }
    }
}
