/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package PegawaiClass;
import Koneksi.Koneksi;

/**
 *
 * @author Alif
 */
/* Nama program : KalkulatorClass.java
Nama : Alif Al Husaini
NPM : 140810220036
Tanggal buat  29 November 2023
Deskripsi : Class Pegawai
----------------------------------------------------------------- */
public class PegawaiClass {

    private String nama;
    private String nip;
    private int golongan;

    public PegawaiClass() {
        this.nama = "";
        this.nip = "";
        this.golongan = 0;
    }

    public String getNama() {
        return this.nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNip() {
        return this.nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public int getGolongan() {
        return this.golongan;
    }

    public void setGolongan(int golongan) {
        this.golongan = golongan;
    }

    public long hitungGaji() {
        switch (this.golongan) {
            case 1:
                return 4000000;
            case 2:
                return 6000000;
            default:
                return 8000000;
        }
    }

    public String insertPegawai() {
        Koneksi kon = new Koneksi();

        long gaji = hitungGaji();

        String query = "INSERT INTO pegawai (nama, nip, golongan, gaji) VALUES ('" + this.nama + "','" + this.nip + "'," + this.golongan + "," + gaji + ")";

        kon.query(query);

        return query;
    }

    public String updatePegawai() {
        Koneksi kon = new Koneksi();

        long gaji = hitungGaji(); 

        String query = "UPDATE pegawai SET nama='" + this.nama + "', golongan=" + this.golongan + ", gaji=" + gaji + " WHERE nip='" + this.nip + "'";

        kon.query(query);

        return query;
    }

    public String deletePegawai() {
        Koneksi kon = new Koneksi();

        String query = "DELETE FROM pegawai WHERE nip='" + this.nip + "'";

        kon.query(query);

        return query;
    }

}

