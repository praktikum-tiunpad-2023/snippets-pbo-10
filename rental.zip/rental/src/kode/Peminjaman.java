/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package kode;

/**
 *
 * @author Alif
 */
import java.sql.*;

public class Peminjaman {
    private String peminjaman;
    private String pelanggan;
    private String mobil;
    private String petugas;
    private String ptanggal;
    private String pbulan;
    private String ptahun;
    private String lama;
    private String ktahun;
    private String pegawai;
    private String biaya;
    private String telat;
    private String denda;

    public Peminjaman() {}

 

    public void setPeminjaman(String peminjaman) {
        this.peminjaman = peminjaman;
    }

    public String getPelanggan() {
        return pelanggan;
    }

    public void setPelanggan(String pelanggan) {
        this.pelanggan = pelanggan;
    }

    public String getMobil() {
        return mobil;
    }

    public void setMobil(String mobil) {
        this.mobil = mobil;
    }

    public String getPetugas() {
        return petugas;
    }

    public void setPetugas(String petugas) {
        this.petugas = petugas;
    }

    public String getPtanggal() {
        return ptanggal;
    }

    public void setPtanggal(String ptanggal) {
        this.ptanggal = ptanggal;
    }

    public String getPbulan() {
        return pbulan;
    }

    public void setPbulan(String pbulan) {
        this.pbulan = pbulan;
    }

    public String getPtahun() {
        return ptahun;
    }

    public void setPtahun(String ptahun) {
        this.ptahun = ptahun;
    }

    public String getLama() {
        return lama;
    }

    public void setLama(String lama) {
        this.lama = lama;
    }

    public String getKtahun() {
        return ktahun;
    }

    public void setKtahun(String ktahun) {
        this.ktahun = ktahun;
    }

    public String getPegawai() {
        return pegawai;
    }

    public void setPegawai(String pegawai) {
        this.pegawai = pegawai;
    }

    public String getBiaya() {
        return biaya;
    }

    public void setBiaya(String biaya) {
        this.biaya = biaya;
    }

    public String getTelat() {
        return telat;
    }

    public void setTelat(String telat) {
        this.telat = telat;
    }

    public String getDenda() {
        return denda;
    }

    public void setDenda(String denda) {
        this.denda = denda;
    }
    public void insertPeminjaman() {
    Koneksi kon = new Koneksi();
    String formattedDate = this.ptahun + "-" + this.pbulan + "-" + this.ptanggal;
    String s = "INSERT INTO peminjaman (id_peminjaman, id_mobil, id_pelanggan, id_petugas, tgl_pinjam, tgl_hrs_kembali, lama, telat, biaya, denda) VALUES ('" + this.peminjaman + "', '" + this.mobil + "', '" + this.pelanggan + "', '" + this.petugas + "', '" + formattedDate + "', '" + this.ktahun + "', '" + this.lama + "', '0', '" + this.biaya + "', '0')";
    kon.query(s);
    kon.closeConnection();
}


    public void updatePeminjaman() {
        Koneksi kon = new Koneksi();
        String s = "UPDATE peminjaman SET telat = '" + this.telat + "', denda = '" + this.denda + "' WHERE id_peminjaman = '" + this.peminjaman + "'";
        kon.query(s);
        kon.closeConnection();
    }

    public void deletePeminjaman() {
        Koneksi kon = new Koneksi();
        String s = "DELETE FROM peminjaman WHERE id_peminjaman = '" + this.peminjaman + "'";
        kon.query(s);
        kon.closeConnection();
    }

    public ResultSet getPeminjaman() {
        ResultSet r = null;
        Koneksi kon = new Koneksi();
        String s = "SELECT * FROM peminjaman WHERE id_peminjaman = '" + this.peminjaman + "'";
        r = kon.getData(s);
        return r;
    }
}
