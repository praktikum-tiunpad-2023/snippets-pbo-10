/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package kode;

/**
 *
 * @author Alif
 */
import java.sql.*;

public class Pelanggan {

    private String id;
    private String nama;
    private String alamat;
    private String cp;
    private String status;

    public Pelanggan() {
    }

    public String getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getCp() {
        return cp;
    }

    public String getStatus() {
        return status;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void insertPelanggan() {
        Koneksi kon = new Koneksi();
        String s = "INSERT INTO pelanggan VALUES ('" + this.id + "', '" + this.nama + "', '" + this.cp + "', '" + this.alamat + "')";
        kon.query(s);
    }

    public void updatePelanggan() {
        Koneksi kon = new Koneksi();
        String s = "UPDATE pelanggan SET id_pelanggan = '" + this.id + "', nama = '" + this.nama + "', cp = '" + this.cp + "', alamat = '" + this.alamat + "' WHERE id_pelanggan = '" + this.id + "'";
        kon.query(s);
    }

    public void deletePelanggan() {
        Koneksi kon = new Koneksi();
        String s = "DELETE FROM pelanggan WHERE id_pelanggan = '" + this.id + "'";
        kon.query(s);
    }

    public ResultSet getPelanggan() {
        ResultSet r = null;
        Koneksi kon = new Koneksi();
        String s = "SELECT * FROM t_pelangganxxx";
        r = kon.getData(s);
        return r;
    }
}
